<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css"rel="stylesheet"/>
</head>
<body>
    <div class="row justify-content-center align-items-center ">
        <div class="col">
            <img src="images/logo.png" class="img-fluid mx-auto d-block" style="width: 80px" alt="" srcset="" />
            <h3 class="mb-4 pb-2 pb-md-0 mb-md-5 h5 text-center">
                Sign up into your account
            </h3>
        </div>
    </div>
    <?php
  if (isset($_POST["save"])) {
    $conn = mysqli_connect('localhost', 'root', '', 'report-site') or die('connection faile'.mysqli_connect_error());

    $fname = mysqli_real_escape_string($conn,$_POST["fname"]);
    $lname = mysqli_real_escape_string($conn,$_POST["lname"]);
    $user = mysqli_real_escape_string($conn,$_POST["username"]);
    $phone = $_POST["mobileno"];
    $password = mysqli_real_escape_string($conn, md5($_POST["password"]));
    $designation = mysqli_real_escape_string($conn,$_POST["designation"]);

    $sql = "SELECT username FROM users WHERE username = '{$user}' ";
    $result = mysqli_query($conn, $sql) or die("query failed");

    if (mysqli_num_rows($result) > 0) {
      echo "user already exist";
    }else{



      $sqli = "INSERT INTO users (firstName, lastName, username, phone, user_password, designation) 
            VALUES
            ('{$fname}','{$lname}','{$user}','{$phone}','{$password}','{$designation}')";

      if(mysqli_query($conn,$sqli)){
        header("Location: https://www.google.com/");
      } else {
        echo "fail";
      }};
    };

  ?>
    <form action="<?php  $_SERVER['PHP_SELF'];?>" method="POST" id="form"class="w-50 p-5">
        <div class="row">
            <div class="col-md-6 mb-4">
                <div class="form-outline remove-focus">
                    <label class="form-label" for="firstName">First Name</label>
                    <input type="text" id="fname" name="fname" class="form-control form-control-lg"
                        placeholder="Jhon" />
                    <small class="text-danger"></small>
                </div>
            </div>


            <div class="col-md-6 mb-4">
                <div class="form-outline remove-focus">
                    <label class="form-label" for="lastName">Last Name</label>
                    <input type="text" id="lname" name="lname" class="form-control form-control-lg" placeholder="Doe" />
                    <small class="text-danger"></small>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 mb-4">
                <div class="form-outline remove-focus">
                    <label class="form-label" for="username">username</label>
                    <input type="text" id="username" name="username" class="form-control form-control-lg"
                        placeholder="jhon123" />
                    <small class="text-danger"></small>
                </div>
            </div>
            <div class="col-md-6 mb-4">
                <div class="form-outline remove-focus">
                    <label class="form-label" for="mobileNo">Mobile No</label>
                    <input type="number" id="phone" name="mobileno" class="form-control form-control-lg"
                        placeholder="01*********" />
                    <small class="text-danger"></small>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 mb-4">
                <div class="form-outline remove-focus">
                    <label class="form-label" for="password">Password</label>
                    <input type="password" id="password" name="password" class="form-control form-control-lg"
                        placeholder="******" />
                    <small class="text-danger"></small>
                </div>
            </div>
            <div class="col-md-6 mb-4">
                <div class="form-outline remove-focus">
                    <label class="form-label" for="lastName">Confirm Password</label>
                    <input type="password" id="cpassword" name="cpassword" class="form-control form-control-lg"
                        placeholder="******" />
                    <small class="text-danger"></small>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <label class="form-label select-label">Your Designation</label>
                <br />
                <select class="select form-control-lg" name="designation">
                    <option value="1" disabled>Choose option</option>
                    <option value="2">product Auditor</option>
                    <option value="3">packing auditor</option>
                    <option value="4">qms auditor</option>
                    <option value="5">GPQ</option>
                    <option value="6">QA incharge</option>
                </select>
            </div>
        </div>

        <div class="mt-4 pt-2 d-flex align-items-center justify-content-between">
            <input type="submit" class="btn bg-success px-5 py-2 " name="save" value="submit">

        </div>
    </form>
    </div>
<p>note: if you feel hassel with password then copy and paste 3w&&aVk42%GJ</p>

    <script src="valid.js"></script>
</body>

</html>